DELETE FROM Amministratore WHERE idAmministratore != 0;
insert into Amministratore(idAmministratore, Utente_idUtente) values (1,21);
insert into Amministratore(idAmministratore, Utente_idUtente) values (2,22);