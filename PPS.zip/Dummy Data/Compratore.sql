DELETE FROM Compratore WHERE idCompratore != 0;
insert into Compratore (idCompratore, Utente_idUtente) values (1,25);
insert into Compratore (idCompratore, Utente_idUtente) values (2,26);