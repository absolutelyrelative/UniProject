DELETE FROM Venditore WHERE idVenditore != 0;
insert into Venditore (idVenditore, Utente_idUtente) values (1,23);
insert into Venditore (idVenditore, Utente_idUtente) values (2,24);