package it.unisalento.pps.SimpleBooking.DAO.Interface;

import it.unisalento.pps.SimpleBooking.Model.Utente;

public interface IUtenteDAO extends IBaseDAO<Utente> {
}
