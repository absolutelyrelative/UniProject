package it.unisalento.pps.SimpleBooking.DAO.Interface;

import it.unisalento.pps.SimpleBooking.Model.Amministratore;


public interface IAmministratoreDAO extends IBaseDAO<Amministratore> {
}
