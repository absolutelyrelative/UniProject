package it.unisalento.pps.SimpleBooking.DAO.Interface;

import it.unisalento.pps.SimpleBooking.Model.Venditore;

public interface IVenditoreDAO extends IBaseDAO<Venditore> {
}
