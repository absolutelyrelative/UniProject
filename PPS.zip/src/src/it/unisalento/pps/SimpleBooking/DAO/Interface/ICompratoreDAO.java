package it.unisalento.pps.SimpleBooking.DAO.Interface;

import it.unisalento.pps.SimpleBooking.Model.Compratore;

public interface ICompratoreDAO extends IBaseDAO<Compratore> {

}
